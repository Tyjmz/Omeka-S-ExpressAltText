# ExpressAltText 1.0.1 (development build)

An Omeka S 4.x admin dashboard for reviewing and editing the native `o:alt_text` field on image media.

## Changes from 1.0.0
- Registers a standalone `/admin/express-alt-text` route with a matching navigation route name and explicit view template mapping.
- Saves through Omeka's API manager with a partial media update, instead of directly flushing an ORM entity.
- Uses a redirect after successful POST to avoid accidental resubmission.
- Catches save failures and logs them rather than exposing a stack trace.

## Install / upgrade
1. **Back up the site and database. Test on a staging copy first.** This build has not been tested against a running Omeka S 4.2.1 instance.
2. Uninstall ExpressAltText 1.0.0 in Admin > Modules if possible. No custom tables are created by this module.
3. Remove or rename the old `modules/ExpressAltText` directory (do not nest the replacement inside it).
4. Extract the ZIP so that `modules/ExpressAltText/Module.php` exists.
5. Install Express Alt Text in Admin > Modules, then click the sidebar link.
6. Confirm the dashboard loads. Test saving alt text on a non-critical image and verify the result in Omeka's native media editor and on the public page.

## Important limitations
- The module edits the **native media-level alt text**, but themes and page blocks may override the rendered public HTML `alt` attribute. It does not audit public page output.
- Empty alt text may be intentional for decorative images; the 'missing' filter does not distinguish that case.
- No reviewed-status tracking, search, or per-page override editor is included yet.
- Image media pagination is 30 records per page.
- This module does not require the Common module.

If the dashboard shows a 404, check Omeka's application cache and logs. If a 500 occurs, rename `modules/ExpressAltText` to disable it and restore your backup if needed.
